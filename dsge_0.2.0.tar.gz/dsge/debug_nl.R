library(dsge)

rbc <- dsgenl_model(
  "1/C = beta / C(+1) * (alpha * exp(Z) * K^(alpha-1) + 1 - delta)",
  "K(+1) = exp(Z) * K^alpha - C + (1 - delta) * K",
  "Z(+1) = rho * Z",
  observed = "C", endo_state = "K", exo_state = "Z",
  fixed = list(alpha = 0.33, beta = 0.99, delta = 0.025),
  start = list(rho = 0.9),
  ss_guess = c(C = 2, K = 30, Z = 0)
)

params <- c(alpha = 0.33, beta = 0.99, delta = 0.025, rho = 0.9)
sol <- solve_dsge(rbc, params = params, shock_sd = c(Z = 0.01))
ss <- steady_state(rbc, params = params)

cat("G:\n"); print(sol$G)
cat("H:\n"); print(sol$H)
cat("M:\n"); print(sol$M)
cat("D:\n"); print(sol$D)

# Simulate data
set.seed(123)
n <- 200
x_dev <- matrix(0, n, 2)
for (t in 2:n) {
  e <- rnorm(1)
  x_dev[t,] <- as.numeric(sol$H %*% x_dev[t-1,] + sol$M %*% e)
}
c_sim <- ss$values[["C"]] + x_dev %*% t(sol$G)
dat <- data.frame(C = as.numeric(c_sim))

# Evaluate loglik at different rho values
y_raw <- as.matrix(dat)

rho_vals <- c(-0.32, 0.0, 0.3, 0.5, 0.7, 0.85, 0.9, 0.95)
sd_vals <- c(0.005, 0.01, 0.02, 0.05)

for (rho_try in rho_vals) {
  for (sd_try in sd_vals) {
    p <- c(alpha = 0.33, beta = 0.99, delta = 0.025, rho = rho_try)
    tryCatch({
      s <- solve_dsge(rbc, params = p, shock_sd = c(Z = sd_try))
      if (!s$stable) {
        cat(sprintf("rho=%6.3f sd=%7.4f UNSTABLE\n", rho_try, sd_try))
        next
      }
      obs_ss <- s$steady_state["C"]
      y_dev <- sweep(y_raw, 2, obs_ss)
      kf <- dsge:::kalman_filter(y_dev, s$G, s$H, s$M, s$D)
      cat(sprintf("rho=%6.3f sd=%7.4f loglik=%10.3f\n", rho_try, sd_try, kf$loglik))
    }, error = function(e) {
      cat(sprintf("rho=%6.3f sd=%7.4f ERROR: %s\n", rho_try, sd_try, e$message))
    })
  }
}
