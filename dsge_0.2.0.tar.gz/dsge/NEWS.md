# dsge 0.2.0

## Nonlinear DSGE support

* New `dsgenl_model()` constructor for nonlinear DSGE models defined via
  string-based equations with `VAR(+1)` lead notation.
* `steady_state()` generic for computing the deterministic steady state
  via Newton-Raphson with damped line search. Supports user-supplied
  analytical steady-state functions.
* `linearize()` computes first-order Taylor expansion around steady state,
  mapping the Jacobian blocks into the existing canonical structural form.
* `solve_dsge()` now accepts `dsgenl_model` objects: automatically computes
  steady state, linearizes, and solves via the existing Klein solver.
* `estimate()` now accepts `dsgenl_model` objects: re-linearizes at each
  parameter evaluation, subtracts model-implied steady state from data.
* All existing postestimation tools (policy matrix, transition matrix,
  stability, IRFs, forecasts, predict, residuals) work with nonlinear
  models after linearization.
* Extended Klein solver to handle A4 matrix (lead-state terms in control
  equations) for broader model classes.

## Limitations

* Nonlinear support uses first-order perturbation only; second-order and
  higher approximations are not yet implemented.
* Bayesian estimation is not yet available.
* Steady-state solving is numerical; convergence depends on initial guesses.

# dsge 0.1.0

Initial CRAN release.

## Model specification

* Formula-based model specification via `obs()`, `unobs()`, and `state()`
  equation wrappers.
* Forward expectations via `lead(x)` (core primitive) and `E(x)` (alias).
* Fixed and free parameter separation with arbitrary nonlinear
  parameter expressions in coefficients.
* Endogenous state variables via `state(, shock = FALSE)`.

## Solution

* Klein (2000) solution via the method of undetermined coefficients.
* Blanchard-Kahn saddle-path stability diagnostics.
* Policy matrix G and transition matrix H extraction.

## Estimation

* Maximum likelihood estimation via Kalman filter log-likelihood.
* Log-parameterization of shock standard deviations for positivity.
* Delta-method standard errors for all estimated quantities.
* Standard R methods: `coef()`, `vcov()`, `logLik()`, `nobs()`,
  `predict()`, `residuals()`, `summary()`.

## Postestimation

* Policy and transition matrix extraction with delta-method standard errors.
* Stability check with eigenvalue classification.
* Impulse-response functions with confidence bands.
* Dynamic multi-step forecasting from filtered states.
* `predict()` with one-step-ahead and filtered/smoothed modes.

## Plotting

* `plot.dsge_irf()` for multi-panel IRF plots with CI bands.
* `plot.dsge_forecast()` for forecast visualization.
